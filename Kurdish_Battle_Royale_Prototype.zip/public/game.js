import * as THREE from "three";

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x91c9dc);
scene.fog = new THREE.Fog(0x91c9dc, 45, 110);
const camera = new THREE.PerspectiveCamera(65, innerWidth/innerHeight, .1, 180);
const renderer = new THREE.WebGLRenderer({antialias:true, powerPreference:"low-power"});
renderer.setSize(innerWidth, innerHeight); renderer.setPixelRatio(Math.min(devicePixelRatio, 1.6));
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
document.body.appendChild(renderer.domElement);
scene.add(new THREE.HemisphereLight(0xe6f7ff,0x52613a,2.1));
const sun = new THREE.DirectionalLight(0xfff0c8,2.5); sun.position.set(20,35,12); sun.castShadow=true; scene.add(sun);
const mat = (color, roughness=1) => new THREE.MeshStandardMaterial({color,roughness});
const ground = new THREE.Mesh(new THREE.PlaneGeometry(120,120), mat(0x6c9b55)); ground.rotation.x=-Math.PI/2; ground.receiveShadow=true; scene.add(ground);
const grid = new THREE.GridHelper(100,50,0x8fb477,0x7ca36a); grid.position.y=.015; scene.add(grid);
function box(x,y,z,sx,sy,sz,color){const m=new THREE.Mesh(new THREE.BoxGeometry(sx,sy,sz),mat(color));m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;scene.add(m);return m}
function tree(x,z){const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.18,.28,1.5,6),mat(0x6e492c));trunk.position.set(x,.75,z);trunk.castShadow=true;scene.add(trunk);const crown=new THREE.Mesh(new THREE.ConeGeometry(1.1,2.5,7),mat([0x2e7141,0x3f8147,0x4b8b50][Math.floor(Math.random()*3)]));crown.position.set(x,2.5,z);crown.castShadow=true;scene.add(crown)}
for(let i=0;i<85;i++){let x=(Math.random()-.5)*100,z=(Math.random()-.5)*100;if(Math.abs(x)>5||Math.abs(z)>5)tree(x,z)}
// Small huts and rocky landmarks
for(let i=0;i<9;i++){let x=(Math.random()-.5)*65,z=(Math.random()-.5)*65;if(Math.abs(x)<9&&Math.abs(z)<9)continue;box(x,.8,z,3,1.6,3,0xb9a078);const roof=new THREE.Mesh(new THREE.ConeGeometry(2.6,1.5,4),mat(0x79523b));roof.position.set(x,2.25,z);roof.rotation.y=Math.PI/4;scene.add(roof)}
// Safe-zone ring (visual prototype)
const ring = new THREE.Mesh(new THREE.TorusGeometry(28,.12,8,120),new THREE.MeshBasicMaterial({color:0x40f5d0}));ring.rotation.x=Math.PI/2;ring.position.y=.08;scene.add(ring);
const crystalMat = new THREE.MeshStandardMaterial({color:0x39e6ff,emissive:0x007d99,emissiveIntensity:2,metalness:.2,roughness:.25});
const crystals=[];for(let i=0;i<18;i++){const c=new THREE.Mesh(new THREE.OctahedronGeometry(.48),crystalMat);c.position.set((Math.random()-.5)*70,.8,(Math.random()-.5)*70);c.castShadow=true;scene.add(c);crystals.push(c)}
function makePlayer(color){const g=new THREE.Group();const body=new THREE.Mesh(new THREE.CapsuleGeometry(.45,.8,4,8),mat(color));body.position.y=.9;body.castShadow=true;g.add(body);const head=new THREE.Mesh(new THREE.SphereGeometry(.3,12,8),mat(0xe0b18a));head.position.y=1.65;g.add(head);const marker=new THREE.Mesh(new THREE.ConeGeometry(.22,.4,4),mat(0xffd04a));marker.position.y=2.05;g.add(marker);scene.add(g);return g}
const keys={};addEventListener("keydown",e=>{keys[e.key.toLowerCase()]=true});addEventListener("keyup",e=>{keys[e.key.toLowerCase()]=false});
document.querySelectorAll("[data-key]").forEach(b=>{const k=b.dataset.key;for(const ev of ["pointerdown","touchstart"])b.addEventListener(ev,e=>{e.preventDefault();keys[k]=true});for(const ev of ["pointerup","pointerleave","pointercancel","touchend"])b.addEventListener(ev,e=>{e.preventDefault();keys[k]=false})});
const players=new Map();let myId=null, socket=null, crystalsCount=0, lastSend=0;const statusEl=document.querySelector("#status"),dot=document.querySelector("#dot"),message=document.querySelector("#message"),countEl=document.querySelector("#count");
function connect(){const proto=location.protocol==="https:"?"wss:":"ws:";socket=new WebSocket(`${proto}//${location.host}`);socket.onopen=()=>{statusEl.textContent="Online";dot.style.background="#4ee38b";message.textContent="Connected! Explore and collect crystals.";setTimeout(()=>message.style.display="none",2500)};socket.onclose=()=>{statusEl.textContent="Disconnected";dot.style.background="#ff5757";message.style.display="block";message.textContent="Server disconnected — refresh after server is available."};socket.onerror=()=>{statusEl.textContent="Connection error"};socket.onmessage=e=>{const m=JSON.parse(e.data);if(m.type==="welcome"){myId=m.id;m.players.forEach(addOrUpdate)}if(m.type==="joined")addOrUpdate(m.player);if(m.type==="moved")addOrUpdate(m.player);if(m.type==="left"){const p=players.get(m.id);if(p){scene.remove(p.mesh);players.delete(m.id)}updateCount()}}}
function addOrUpdate(p){let o=players.get(p.id);if(!o){o={mesh:makePlayer(p.color),name:p.name,x:p.x,z:p.z};players.set(p.id,o)}o.name=p.name;o.x=p.x;o.z=p.z;o.mesh.position.set(p.x,0,p.z);updateCount()}
function updateCount(){countEl.textContent=players.size}
connect();
const me=makePlayer("#ffc400");me.visible=false;let x=0,z=0;const speed=8;
document.querySelector("#rename").onclick=()=>{const name=document.querySelector("#name").value.trim().slice(0,16)||"Player";if(socket?.readyState===1)socket.send(JSON.stringify({type:"rename",name}))};
function animate(t){requestAnimationFrame(animate);const dt=Math.min(.04,(t-(animate.last||t))/1000);animate.last=t;
 const forward=(keys.w||keys.arrowup?1:0)-(keys.s||keys.arrowdown?1:0), side=(keys.d||keys.arrowright?1:0)-(keys.a||keys.arrowleft?1:0);
 if(forward||side){const len=Math.hypot(forward,side);x+=side/len*speed*dt;z-=forward/len*speed*dt;x=Math.max(-45,Math.min(45,x));z=Math.max(-45,Math.min(45,z));me.position.set(x,0,z);me.visible=true;me.rotation.y=Math.atan2(side,-forward);if(t-lastSend>60&&socket?.readyState===1){socket.send(JSON.stringify({type:"move",x,z,name:document.querySelector("#name").value.trim().slice(0,16)||"Player"}));lastSend=t}}
 for(const [id,p] of players){if(id!==myId){p.mesh.position.x+=(p.x-p.mesh.position.x)*.25;p.mesh.position.z+=(p.z-p.mesh.position.z)*.25}}
 for(const c of crystals){c.rotation.y+=dt*1.5;c.position.y=.8+Math.sin(t*.002+c.position.x)*.15;if(c.visible&&Math.hypot(c.position.x-x,c.position.z-z)<1.25){c.visible=false;crystalsCount++;document.querySelector("#crystals").textContent=crystalsCount}}
 camera.position.lerp(new THREE.Vector3(x,7,z+10),.12);camera.lookAt(x,1,z);
 renderer.render(scene,camera)}
animate(0);
addEventListener("resize",()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});
