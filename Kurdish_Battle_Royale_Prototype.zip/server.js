const http = require("http");
const fs = require("fs");
const path = require("path");
const WebSocket = require("ws");

const PORT = process.env.PORT || 3000;
const PUBLIC = path.join(__dirname, "public");
const mime = { ".html":"text/html; charset=utf-8", ".js":"text/javascript; charset=utf-8", ".css":"text/css; charset=utf-8", ".json":"application/json; charset=utf-8" };
const server = http.createServer((req, res) => {
  const urlPath = decodeURIComponent((req.url || "/").split("?")[0]);
  const requested = urlPath === "/" ? "/index.html" : urlPath;
  const full = path.normalize(path.join(PUBLIC, requested));
  if (!full.startsWith(PUBLIC)) { res.writeHead(403); return res.end("Forbidden"); }
  fs.readFile(full, (err, data) => {
    if (err) { res.writeHead(404); return res.end("Not found"); }
    res.writeHead(200, { "Content-Type": mime[path.extname(full)] || "application/octet-stream", "Cache-Control":"no-store" });
    res.end(data);
  });
});

const wss = new WebSocket.Server({ server });
const players = new Map();
const names = ["Roj","Baran","Aso","Dilan","Zana","Nishtiman","Hawar","Aram"];
function sendAll(data) {
  const msg = JSON.stringify(data);
  for (const ws of wss.clients) if (ws.readyState === WebSocket.OPEN) ws.send(msg);
}
function safeName(s) {
  return String(s || "Player").replace(/[<>]/g, "").trim().slice(0, 16) || "Player";
}
wss.on("connection", ws => {
  const id = Math.random().toString(36).slice(2, 10);
  const n = players.size;
  const p = { id, name: names[n % names.length], x: (Math.random()-0.5)*16, z: (Math.random()-0.5)*16, color: ["#f5b700","#36c9ff","#ff6b6b","#7be495","#bd8cff"][n%5] };
  players.set(id, p);
  ws.playerId = id;
  ws.send(JSON.stringify({ type:"welcome", id, players:[...players.values()] }));
  sendAll({ type:"joined", player:p });
  ws.on("message", raw => {
    let m;
    try { m = JSON.parse(raw.toString()); } catch { return; }
    const current = players.get(id);
    if (!current) return;
    if (m.type === "move" && Number.isFinite(m.x) && Number.isFinite(m.z)) {
      current.x = Math.max(-45, Math.min(45, m.x));
      current.z = Math.max(-45, Math.min(45, m.z));
      if (typeof m.name === "string") current.name = safeName(m.name);
      sendAll({ type:"moved", player:current });
    }
    if (m.type === "rename") {
      current.name = safeName(m.name);
      sendAll({ type:"moved", player:current });
    }
  });
  ws.on("close", () => {
    players.delete(id);
    sendAll({ type:"left", id });
  });
});
server.listen(PORT, "0.0.0.0", () => console.log(`Kurdish Battle Royale running on http://localhost:${PORT}`));